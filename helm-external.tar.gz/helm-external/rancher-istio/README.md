# rancher-istio

[DEPRECATED] in favor on Istio's upstream [charts](../istio)
