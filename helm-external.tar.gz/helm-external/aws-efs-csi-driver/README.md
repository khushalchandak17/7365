#  aws-efs-csi-driver

## Kustomize

Please review the [patch](kustomize/clusterrole.yaml) in the `kustomize` directory.

## Issue

Please read about this ongoing [issue](https://gitlab.industrysoftware.automation.siemens.com/caas-ops/operational-manual/-/blob/master/docs/issues/issue-efs.md) in the Operational Manual.
